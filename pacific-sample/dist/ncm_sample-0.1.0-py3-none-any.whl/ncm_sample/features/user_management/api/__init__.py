"""
User Management API Router
"""

from .user_router import router as user_router, init_feature

__all__ = ["user_router", "init_feature"]
