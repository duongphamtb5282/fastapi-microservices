"""
UserRole Repository - Data Access Layer
"""

from datetime import datetime
from typing import Any, Dict, List, Optional
from sqlalchemy import select, and_, desc
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from ncm_foundation.core.database.repositories.sqlalchemy_repo import SQLAlchemyRepository
from ncm_foundation.core.logging import get_logger
from ncm_sample.features.user_management.models import UserRole, User, Role

logger = get_logger(__name__)


class UserRoleRepository(SQLAlchemyRepository[UserRole]):
    """Repository for UserRole entities using NCM Foundation SQLAlchemyRepository."""

    def __init__(self, session: AsyncSession):
        super().__init__(UserRole, session)

    async def get_by_user_and_role(self, user_id: Any, role_id: Any) -> Optional[UserRole]:
        """Get user role by user and role IDs."""
        result = await self.session.execute(
            select(UserRole)
            .where(and_(UserRole.user_id == user_id, UserRole.role_id == role_id))
            .options(selectinload(UserRole.user), selectinload(UserRole.role))
        )
        return result.scalar_one_or_none()

    async def get_user_roles(self, user_id: Any, active_only: bool = True) -> List[UserRole]:
        """Get all roles for a user."""
        filters = {"user_id": user_id}
        if active_only:
            filters["is_active"] = True

        return await self.list(
            filters=filters,
            order_by="created_at"
        )

    async def get_role_users(self, role_id: Any, active_only: bool = True) -> List[UserRole]:
        """Get all users for a role."""
        filters = {"role_id": role_id}
        if active_only:
            filters["is_active"] = True

        return await self.list(
            filters=filters,
            order_by="created_at"
        )

    async def assign_role(self, user_id: Any, role_id: Any, assigned_by: str) -> UserRole:
        """Assign role to user."""
        # Check if assignment already exists
        existing = await self.get_by_user_and_role(user_id, role_id)
        if existing:
            # Reactivate if exists but inactive
            if not existing.is_active:
                await self.update(existing.id, {
                    "is_active": True,
                    "assigned_by": assigned_by
                })
            return existing

        # Create new assignment
        return await self.create({
            "user_id": user_id,
            "role_id": role_id,
            "assigned_by": assigned_by
        })

    async def revoke_role(self, user_id: Any, role_id: Any) -> bool:
        """Revoke role from user."""
        user_role = await self.get_by_user_and_role(user_id, role_id)
        if user_role:
            return await self.update(user_role.id, {"is_active": False}) is not None
        return False

    async def get_active_assignments(self, limit: int = 100, offset: int = 0) -> List[UserRole]:
        """Get active user role assignments."""
        return await self.list(
            filters={"is_active": True},
            limit=limit,
            offset=offset,
            order_by="created_at"
        )

    async def get_expired_assignments(self) -> List[UserRole]:
        """Get expired user role assignments."""
        # This requires custom implementation due to datetime comparison
        result = await self.session.execute(
            select(UserRole)
            .where(UserRole.expires_at < datetime.utcnow())
            .options(selectinload(UserRole.user), selectinload(UserRole.role))
        )
        return result.scalars().all()

    async def cleanup_expired_assignments(self) -> int:
        """Clean up expired user role assignments."""
        expired_assignments = await self.get_expired_assignments()
        count = len(expired_assignments)

        for assignment in expired_assignments:
            await self.update(assignment.id, {"is_active": False})

        return count
