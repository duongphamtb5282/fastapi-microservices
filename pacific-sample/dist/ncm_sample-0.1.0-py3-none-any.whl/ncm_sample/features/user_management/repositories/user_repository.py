"""
User Repository - Data Access Layer
"""

from typing import Any, Dict, List, Optional
from sqlalchemy import select, and_, or_, desc
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from ncm_foundation.core.database.repositories.sqlalchemy_repo import SQLAlchemyRepository
from ncm_foundation.core.logging import get_logger
from ncm_sample.di.py_nest_compat import Repository
from ncm_sample.features.user_management.models import User, UserRole

logger = get_logger(__name__)


@Repository
class UserRepository(SQLAlchemyRepository[User]):
    """Repository for User entities using NCM Foundation SQLAlchemyRepository."""

    def __init__(self, session: AsyncSession):
        super().__init__(User, session)

    async def get_by_email(self, email: str) -> Optional[User]:
        """Get user by email with roles loaded."""
        result = await self.session.execute(
            select(User)
            .where(User.email == email)
            .options(selectinload(User.roles))
        )
        return result.scalar_one_or_none()

    async def get_by_username(self, username: str) -> Optional[User]:
        """Get user by username with roles loaded."""
        result = await self.session.execute(
            select(User)
            .where(User.username == username)
            .options(selectinload(User.roles))
        )
        return result.scalar_one_or_none()

    async def activate_user(self, user_id: Any) -> bool:
        """Activate user."""
        return await self.update(user_id, {"is_active": True}) is not None

    async def deactivate_user(self, user_id: Any) -> bool:
        """Deactivate user."""
        return await self.update(user_id, {"is_active": False}) is not None

    async def verify_user(self, user_id: Any) -> bool:
        """Verify user."""
        return await self.update(user_id, {"is_verified": True}) is not None

    async def search_users(self, search_term: str, limit: int = 20) -> List[User]:
        """Search users by email, username, first name, or last name."""
        return await self.search(
            query=search_term,
            fields=["email", "username", "first_name", "last_name"],
            limit=limit
        )

    async def get_users_by_role(self, role_id: str) -> List[User]:
        """Get users by role ID."""
        # This is a complex query that requires custom implementation
        result = await self.session.execute(
            select(User)
            .join(UserRole)
            .where(UserRole.role_id == role_id)
            .where(UserRole.is_active == True)
            .options(selectinload(User.roles))
        )
        return result.scalars().all()

    async def get_active_users(self, limit: int = 100, offset: int = 0) -> List[User]:
        """Get active users."""
        return await self.list(
            filters={"is_active": True},
            limit=limit,
            offset=offset,
            order_by="created_at"
        )
