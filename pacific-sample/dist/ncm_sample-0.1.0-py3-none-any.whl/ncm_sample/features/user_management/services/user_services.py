"""
User Management Services for NCM Sample Project.
"""

import asyncio
import hashlib
import json
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from passlib.context import CryptContext
from jose import JWTError, jwt
from ncm_foundation import get_logger, CacheManager, DatabaseManager
from ncm_sample.di.py_nest_compat import Service
from ncm_foundation.core.cache import CacheStrategy
from ncm_foundation.core.cache.multi_level import MultiLevelCache, CacheLevel
from ncm_foundation.core.cache.redis_cache import RedisCache, SerializationType
from ncm_sample.config import settings
from ncm_sample.features.user_management.models import User, Role, UserRole
from ncm_sample.features.user_management.schemas import UserCreate, UserUpdate, RoleCreate, RoleUpdate, UserRoleCreate
from ncm_sample.features.user_management.repositories import UserRepository, RoleRepository, UserRoleRepository

logger = get_logger(__name__)

# Password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


@Service
class UserService:
    """User service with advanced caching and logging using repository pattern."""

    def __init__(self, db_manager: DatabaseManager, cache_manager: CacheManager):
        self.db_manager = db_manager
        self.cache_manager = cache_manager
        self.user_repository = None  # Will be initialized when needed

        # Initialize multi-level cache for enhanced performance
        if hasattr(cache_manager, 'cache') and hasattr(cache_manager.cache, 'l2_cache'):
            # Use multi-level cache if available
            self.multi_cache = MultiLevelCache(
                l2_cache=cache_manager.cache.l2_cache,
                l1_max_size=settings.get('cache_l1_max_size', 1000),
                l1_default_ttl=settings.get('cache_l1_ttl', 300),
                l2_default_ttl=settings.get('cache_l2_ttl', 3600),
                enable_promotion=True,
                enable_stampede_prevention=True,
                promotion_threshold=3,
                compression_threshold=1024,
            )
        else:
            self.multi_cache = None

        # Cache loader decorators for common operations
        if self.multi_cache:
            self.get_user_by_id_cached = self.multi_cache.cache_loader(
                ttl=1800,  # 30 minutes for user data
                key_func=lambda user_id: f"user:{user_id}"
            )(self._get_user_by_id_from_db)

            self.get_user_by_email_cached = self.multi_cache.cache_loader(
                ttl=1800,
                key_func=lambda email: f"user:email:{email}"
            )(self._get_user_by_email_from_db)

            self.list_users_cached = self.multi_cache.cache_loader(
                ttl=300,  # 5 minutes for user lists
                key_func=lambda limit, offset: f"users:list:{limit}:{offset}"
            )(self._list_users_from_db)

    async def create_user(self, user_data: UserCreate, created_by: str = "system") -> User:
        """Create a new user with caching and audit logging using repository pattern."""
        logger.info(f"Creating user: {user_data.email}")

        # Hash password
        password_hash = pwd_context.hash(user_data.password)

        # Prepare user data for repository
        user_data_dict = {
            "email": user_data.email,
            "username": user_data.username,
            "first_name": user_data.first_name,
            "last_name": user_data.last_name,
            "phone": user_data.phone,
            "avatar_url": user_data.avatar_url,
            "password_hash": password_hash,
            "created_by": created_by
        }

        # Get database session
        async with self.db_manager.get_connection_context() as session:
            # Initialize repository if needed
            if not self.user_repository:
                self.user_repository = UserRepository(session)

            # Create user through repository
            user = await self.user_repository.create(user_data_dict)

        # Log creation audit event
        await user.log_creation(created_by)

        # Cache user data using multi-level cache
        if self.multi_cache:
            await self.multi_cache.set(f"user:{user.id}", user.to_dict(), ttl=1800)
            await self.multi_cache.set(f"user:email:{user.email}", user.to_dict(), ttl=1800)

        # Invalidate list caches
        if self.multi_cache:
            await self.multi_cache.clear_pattern("users:list:*")

        logger.info(f"User created successfully: {user.id}")
        return user

    async def get_user_by_id(self, user_id: str) -> Optional[User]:
        """Get user by ID with multi-level cache strategy using repository pattern."""
        if self.multi_cache:
            # Use cached version with loader fallback
            user_data = await self.multi_cache.get(f"user:{user_id}")
            if user_data:
                logger.debug(f"User {user_id} found in multi-level cache")
                return User(**user_data)

        # Fallback to repository call if cache miss
        return await self._get_user_by_id_from_repo(user_id)

    async def _get_user_by_id_from_repo(self, user_id: str) -> Optional[User]:
        """Internal method to get user from repository."""
        async with self.db_manager.get_connection_context() as session:
            if not self.user_repository:
                self.user_repository = UserRepository(session)

            user = await self.user_repository.get_by_id(user_id)

        if user:
            logger.debug(f"User {user_id} retrieved from repository")
            # Log access for audit
            await user.log_update("system")  # Mark as accessed

        return user

    async def get_user_by_email(self, email: str) -> Optional[User]:
        """Get user by email with multi-level caching using repository pattern."""
        if self.multi_cache:
            # Use cached version with loader fallback
            user_data = await self.multi_cache.get(f"user:email:{email}")
            if user_data:
                logger.debug(f"User {email} found in multi-level cache")
                return User(**user_data)

        # Fallback to repository call if cache miss
        return await self._get_user_by_email_from_repo(email)

    async def _get_user_by_email_from_repo(self, email: str) -> Optional[User]:
        """Internal method to get user from repository by email."""
        async with self.db_manager.get_connection_context() as session:
            if not self.user_repository:
                self.user_repository = UserRepository(session)

            user = await self.user_repository.get_by_email(email)

        if user:
            logger.debug(f"User {email} retrieved from repository")
            # Log access for audit
            await user.log_update("system")  # Mark as accessed

        return user

    async def update_user(self, user_id: str, user_data: UserUpdate, updated_by: str = "system") -> Optional[User]:
        """Update user with cache invalidation using repository pattern."""
        # Prepare update data
        update_data = user_data.dict(exclude_unset=True)
        update_data["updated_by"] = updated_by

        async with self.db_manager.get_connection_context() as session:
            if not self.user_repository:
                self.user_repository = UserRepository(session)

            user = await self.user_repository.update(user_id, update_data)

        if user:
            # Invalidate cache
            await self._invalidate_user_cache(user_id)

            # Cache updated user
            await self._cache_user(user)

            logger.info(f"User {user_id} updated successfully")

        return user

    async def delete_user(self, user_id: str) -> bool:
        """Delete user with cache invalidation using repository pattern."""
        async with self.db_manager.get_connection_context() as session:
            if not self.user_repository:
                self.user_repository = UserRepository(session)

            success = await self.user_repository.delete(user_id)

        if success:
            # Invalidate cache
            await self._invalidate_user_cache(user_id)

            logger.info(f"User {user_id} deleted successfully")

        return success

    async def list_users(self, limit: int = 100, offset: int = 0) -> List[User]:
        """List users with multi-level caching using repository pattern."""
        if self.multi_cache:
            # Use cached version with loader fallback
            users_data = await self.multi_cache.get(f"users:list:{limit}:{offset}")
            if users_data:
                logger.debug(f"User list found in multi-level cache")
                return [User(**user_data) for user_data in users_data]

        # Fallback to repository call if cache miss
        return await self._list_users_from_repo(limit, offset)

    async def _list_users_from_repo(self, limit: int = 100, offset: int = 0) -> List[User]:
        """Internal method to get user list from repository."""
        async with self.db_manager.get_connection_context() as session:
            if not self.user_repository:
                self.user_repository = UserRepository(session)

            users = await self.user_repository.list(limit=limit, offset=offset)

        logger.debug(f"Retrieved {len(users)} users from repository")
        return users

    async def _cache_user(self, user: User) -> None:
        """Cache user data using multi-level cache."""
        if not self.multi_cache:
            return

        user_data = user.to_dict()

        # Cache by ID
        await self.multi_cache.set(f"user:{user.id}", user_data, ttl=1800)

        # Cache by email
        await self.multi_cache.set(f"user:email:{user.email}", user_data, ttl=1800)

    async def _invalidate_user_cache(self, user_id: str) -> None:
        """Invalidate user cache."""
        if not self.multi_cache:
            return

        # Get user to find email (with cache fallback)
        user = await self.get_user_by_id(user_id)
        if user:
            # Clear cache entries
            await self.multi_cache.delete(f"user:{user_id}")
            await self.multi_cache.delete(f"user:email:{user.email}")

        # Clear list caches
        await self.multi_cache.clear_pattern("users:list:*")

    def get_cache_stats(self) -> Dict[str, Any]:
        """Get comprehensive cache statistics."""
        if self.multi_cache:
            return self.multi_cache.get_stats()
        else:
            return self.cache_manager.get_stats() if self.cache_manager else {}

    async def clear_all_cache(self) -> bool:
        """Clear all cache entries."""
        if self.multi_cache:
            return await self.multi_cache.clear_all()
        else:
            return await self.cache_manager.clear_all() if self.cache_manager else False


@Service
class RoleService:
    """Role service with advanced caching using repository pattern."""

    def __init__(self, db_manager: DatabaseManager, cache_manager: CacheManager):
        self.db_manager = db_manager
        self.cache_manager = cache_manager
        self.role_repository = None  # Will be initialized when needed

        # Initialize multi-level cache for enhanced performance
        if hasattr(cache_manager, 'cache') and hasattr(cache_manager.cache, 'l2_cache'):
            self.multi_cache = MultiLevelCache(
                l2_cache=cache_manager.cache.l2_cache,
                l1_max_size=settings.get('cache_l1_max_size', 1000),
                l1_default_ttl=settings.get('cache_l1_ttl', 300),
                l2_default_ttl=settings.get('cache_l2_ttl', 3600),
                enable_promotion=True,
                enable_stampede_prevention=True,
                promotion_threshold=3,
                compression_threshold=1024,
            )
        else:
            self.multi_cache = None

        # Cache loader decorators for common operations
        if self.multi_cache:
            self.get_role_by_id_cached = self.multi_cache.cache_loader(
                ttl=3600,  # 1 hour for roles (less frequently changed)
                key_func=lambda role_id: f"role:{role_id}"
            )(self._get_role_by_id_from_db)

            self.list_roles_cached = self.multi_cache.cache_loader(
                ttl=600,  # 10 minutes for role lists
                key_func=lambda limit, offset: f"roles:list:{limit}:{offset}"
            )(self._list_roles_from_db)

    async def create_role(self, role_data: RoleCreate, created_by: str = "system") -> Role:
        """Create a new role using repository pattern."""
        logger.info(f"Creating role: {role_data.name}")

        # Prepare role data for repository
        role_data_dict = {
            "name": role_data.name,
            "description": role_data.description,
            "permissions": role_data.permissions,
            "created_by": created_by
        }

        async with self.db_manager.get_connection_context() as session:
            if not self.role_repository:
                self.role_repository = RoleRepository(session)

            role = await self.role_repository.create(role_data_dict)

        # Cache role
        await self._cache_role(role)

        logger.info(f"Role created successfully: {role.id}")
        return role

    async def get_role_by_id(self, role_id: str) -> Optional[Role]:
        """Get role by ID with multi-level caching using repository pattern."""
        if self.multi_cache:
            # Use cached version with loader fallback
            role_data = await self.multi_cache.get(f"role:{role_id}")
            if role_data:
                logger.debug(f"Role {role_id} found in multi-level cache")
                return Role(**role_data)

        # Fallback to repository call if cache miss
        return await self._get_role_by_id_from_repo(role_id)

    async def _get_role_by_id_from_repo(self, role_id: str) -> Optional[Role]:
        """Internal method to get role from repository."""
        async with self.db_manager.get_connection_context() as session:
            if not self.role_repository:
                self.role_repository = RoleRepository(session)

            role = await self.role_repository.get_by_id(role_id)

        if role:
            logger.debug(f"Role {role_id} retrieved from repository")
            # Log access for audit
            await role.log_update("system")  # Mark as accessed

        return role

    async def list_roles(self, limit: int = 100, offset: int = 0) -> List[Role]:
        """List roles with multi-level caching using repository pattern."""
        if self.multi_cache:
            # Use cached version with loader fallback
            roles_data = await self.multi_cache.get(f"roles:list:{limit}:{offset}")
            if roles_data:
                logger.debug(f"Role list found in multi-level cache")
                return [Role(**role_data) for role_data in roles_data]

        # Fallback to repository call if cache miss
        return await self._list_roles_from_repo(limit, offset)

    async def _list_roles_from_repo(self, limit: int = 100, offset: int = 0) -> List[Role]:
        """Internal method to get role list from repository."""
        async with self.db_manager.get_connection_context() as session:
            if not self.role_repository:
                self.role_repository = RoleRepository(session)

            roles = await self.role_repository.list(limit=limit, offset=offset)

        logger.debug(f"Retrieved {len(roles)} roles from repository")
        return roles

    async def _cache_role(self, role: Role) -> None:
        """Cache role data."""
        role_data = role.to_dict()
        await self.cache_manager.set(f"role:{role.id}", role_data, ttl=3600)


@Service
class UserRoleService:
    """User role service with advanced caching using repository pattern."""

    def __init__(self, db_manager: DatabaseManager, cache_manager: CacheManager):
        self.db_manager = db_manager
        self.cache_manager = cache_manager
        self.user_role_repository = None  # Will be initialized when needed

        # Initialize multi-level cache for enhanced performance
        if hasattr(cache_manager, 'cache') and hasattr(cache_manager.cache, 'l2_cache'):
            self.multi_cache = MultiLevelCache(
                l2_cache=cache_manager.cache.l2_cache,
                l1_max_size=settings.get('cache_l1_max_size', 1000),
                l1_default_ttl=settings.get('cache_l1_ttl', 300),
                l2_default_ttl=settings.get('cache_l2_ttl', 3600),
                enable_promotion=True,
                enable_stampede_prevention=True,
                promotion_threshold=3,
                compression_threshold=1024,
            )
        else:
            self.multi_cache = None

        # Cache loader decorators for common operations
        if self.multi_cache:
            self.get_user_roles_cached = self.multi_cache.cache_loader(
                ttl=900,  # 15 minutes for user roles
                key_func=lambda user_id: f"user:{user_id}:roles"
            )(self._get_user_roles_from_db)

    async def assign_role(self, user_id: str, role_id: str, assigned_by: str = "system") -> UserRole:
        """Assign role to user using repository pattern."""
        async with self.db_manager.get_connection_context() as session:
            if not self.user_role_repository:
                self.user_role_repository = UserRoleRepository(session)

            user_role = await self.user_role_repository.assign_role(user_id, role_id, assigned_by)

        # Invalidate user cache
        await self.cache_manager.delete(f"user:{user_id}")

        logger.info(f"Role {role_id} assigned to user {user_id}")
        return user_role

    async def get_user_roles(self, user_id: str) -> List[Role]:
        """Get user roles with multi-level caching using repository pattern."""
        if self.multi_cache:
            # Use cached version with loader fallback
            roles_data = await self.multi_cache.get(f"user:{user_id}:roles")
            if roles_data:
                logger.debug(
                    f"User roles for {user_id} found in multi-level cache")
                return [Role(**role_data) for role_data in roles_data]

        # Fallback to repository call if cache miss
        return await self._get_user_roles_from_repo(user_id)

    async def _get_user_roles_from_repo(self, user_id: str) -> List[Role]:
        """Internal method to get user roles from repository."""
        async with self.db_manager.get_connection_context() as session:
            if not self.user_role_repository:
                self.user_role_repository = UserRoleRepository(session)

            user_roles = await self.user_role_repository.get_user_roles(user_id)

        # Extract roles from user role assignments
        roles = [user_role.role for user_role in user_roles]
        logger.debug(
            f"Retrieved {len(roles)} roles for user {user_id} from repository")
        return roles


@Service
class AuthService:
    """Authentication service."""

    def __init__(self, db_manager: DatabaseManager, cache_manager: CacheManager):
        self.db_manager = db_manager
        self.cache_manager = cache_manager
        self.user_service = UserService(db_manager, cache_manager)

    def verify_password(self, plain_password: str, hashed_password: str) -> bool:
        """Verify password."""
        return pwd_context.verify(plain_password, hashed_password)

    def create_access_token(self, data: dict, expires_delta: Optional[timedelta] = None) -> str:
        """Create access token."""
        to_encode = data.copy()
        if expires_delta:
            expire = datetime.utcnow() + expires_delta
        else:
            expire = datetime.utcnow() + timedelta(minutes=settings.jwt_expire_minutes)

        to_encode.update({"exp": expire})
        encoded_jwt = jwt.encode(
            to_encode, settings.jwt_secret, algorithm=settings.jwt_algorithm)
        return encoded_jwt

    async def authenticate_user(self, username: str, password: str) -> Optional[User]:
        """Authenticate user."""
        user = await self.user_service.get_user_by_email(username)
        if not user:
            return None

        if not self.verify_password(password, user.password_hash):
            return None

        return user

    async def login(self, username: str, password: str) -> Optional[dict]:
        """Login user and return token."""
        user = await self.authenticate_user(username, password)
        if not user:
            return None

        access_token_expires = timedelta(minutes=settings.jwt_expire_minutes)
        access_token = self.create_access_token(
            data={"sub": user.username, "user_id": user.id},
            expires_delta=access_token_expires
        )

        return {
            "access_token": access_token,
            "token_type": "bearer",
            "expires_in": settings.jwt_expire_minutes * 60,
            "user": user
        }
