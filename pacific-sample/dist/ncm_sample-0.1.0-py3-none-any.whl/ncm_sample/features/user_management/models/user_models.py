"""
Database models for NCM Sample Project.
"""

import uuid
from datetime import datetime
from typing import Optional, List, Dict, Any
from sqlalchemy import Column, Integer, String, DateTime, Boolean, ForeignKey, Text, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from ncm_foundation.core.database.entities import AuditableEntity, SoftDeleteEntity, VersionedEntity, AuditLoggerImpl
from ncm_foundation.core.database.types import GUID, EncryptedString

Base = declarative_base()

# Initialize audit logger
audit_logger = AuditLoggerImpl()


class User(Base, AuditableEntity):
    """User model with full audit capabilities."""

    __tablename__ = "users"

    # Use GUID for primary key for better security and scalability
    id = Column(GUID, primary_key=True, index=True, default=lambda: str(uuid.uuid4()))
    email = Column(String(255), unique=True, index=True, nullable=False)
    username = Column(String(100), unique=True, index=True, nullable=False)
    first_name = Column(String(100), nullable=False)
    last_name = Column(String(100), nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    is_verified = Column(Boolean, default=False, nullable=False)
    # Use encrypted string for password storage
    password_hash = Column(EncryptedString(255), nullable=False)
    phone = Column(String(20), nullable=True)
    avatar_url = Column(String(500), nullable=True)
    last_login = Column(DateTime, nullable=True)

    # Enhanced audit fields are inherited from AuditableEntity
    # Relationships
    roles = relationship("UserRole", back_populates="user", cascade="all, delete-orphan")

    def __init__(self, **kwargs):
        # Set audit logger for enhanced audit capabilities
        super().__init__(audit_logger=audit_logger, **kwargs)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        data = super().to_dict()
        data.update({
            "email": self.email,
            "username": self.username,
            "first_name": self.first_name,
            "last_name": self.last_name,
            "is_active": self.is_active,
            "is_verified": self.is_verified,
            "phone": self.phone,
            "avatar_url": self.avatar_url,
            "last_login": self.last_login.isoformat() if self.last_login else None,
        })
        return data

    def activate(self, user_id: str) -> None:
        """Activate user."""
        self.is_active = True
        self.update_audit_fields(user_id)

    def deactivate(self, user_id: str) -> None:
        """Deactivate user."""
        self.is_active = False
        self.update_audit_fields(user_id)

    def verify(self, user_id: str) -> None:
        """Verify user."""
        self.is_verified = True
        self.update_audit_fields(user_id)

    def update_login_time(self, user_id: str) -> None:
        """Update last login time."""
        self.last_login = datetime.utcnow()
        self.update_audit_fields(user_id)


class Role(Base, AuditableEntity):
    """Role model with full audit capabilities."""

    __tablename__ = "roles"

    # Use GUID for primary key
    id = Column(GUID, primary_key=True, index=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(100), unique=True, index=True, nullable=False)
    description = Column(Text, nullable=True)
    is_active = Column(Boolean, default=True, nullable=False)
    # Store permissions as JSON for better structure
    permissions = Column(JSON, nullable=True)

    # Enhanced audit fields are inherited from AuditableEntity
    # Relationships
    users = relationship("UserRole", back_populates="role", cascade="all, delete-orphan")

    def __init__(self, **kwargs):
        # Set audit logger for enhanced audit capabilities
        super().__init__(audit_logger=audit_logger, **kwargs)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        data = super().to_dict()
        data.update({
            "name": self.name,
            "description": self.description,
            "is_active": self.is_active,
            "permissions": self.permissions,
        })
        return data

    def activate(self, user_id: str) -> None:
        """Activate role."""
        self.is_active = True
        self.update_audit_fields(user_id)

    def deactivate(self, user_id: str) -> None:
        """Deactivate role."""
        self.is_active = False
        self.update_audit_fields(user_id)

    def add_permission(self, permission: str, user_id: str) -> None:
        """Add permission to role."""
        if not self.permissions:
            self.permissions = []
        if permission not in self.permissions:
            self.permissions.append(permission)
            self.update_audit_fields(user_id)

    def remove_permission(self, permission: str, user_id: str) -> None:
        """Remove permission from role."""
        if self.permissions and permission in self.permissions:
            self.permissions.remove(permission)
            self.update_audit_fields(user_id)

    def has_permission(self, permission: str) -> bool:
        """Check if role has permission."""
        return self.permissions and permission in self.permissions


class UserRole(Base, AuditableEntity):
    """User-Role relationship model with full audit capabilities."""

    __tablename__ = "user_roles"

    # Use GUID for primary key
    id = Column(GUID, primary_key=True, index=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(GUID, ForeignKey("users.id"), nullable=False)
    role_id = Column(GUID, ForeignKey("roles.id"), nullable=False)
    assigned_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    assigned_by = Column(String(100), nullable=True)
    is_active = Column(Boolean, default=True, nullable=False)
    expires_at = Column(DateTime, nullable=True)

    # Enhanced audit fields are inherited from AuditableEntity
    # Relationships
    user = relationship("User", back_populates="roles")
    role = relationship("Role", back_populates="users")

    def __init__(self, **kwargs):
        # Set audit logger for enhanced audit capabilities
        super().__init__(audit_logger=audit_logger, **kwargs)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        data = super().to_dict()
        data.update({
            "user_id": self.user_id,
            "role_id": self.role_id,
            "assigned_at": self.assigned_at.isoformat(),
            "assigned_by": self.assigned_by,
            "is_active": self.is_active,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
        })
        return data

    def activate(self, user_id: str) -> None:
        """Activate user role assignment."""
        self.is_active = True
        self.update_audit_fields(user_id)

    def deactivate(self, user_id: str) -> None:
        """Deactivate user role assignment."""
        self.is_active = False
        self.update_audit_fields(user_id)

    def extend_expiry(self, new_expiry: datetime, user_id: str) -> None:
        """Extend role assignment expiry."""
        self.expires_at = new_expiry
        self.update_audit_fields(user_id)

    def revoke(self, user_id: str) -> None:
        """Revoke role assignment."""
        self.expires_at = datetime.utcnow()
        self.is_active = False
        self.update_audit_fields(user_id)

    def is_expired(self) -> bool:
        """Check if role assignment is expired."""
        return self.expires_at is not None and self.expires_at < datetime.utcnow()

    def is_valid(self) -> bool:
        """Check if role assignment is valid."""
        return self.is_active and not self.is_expired()
