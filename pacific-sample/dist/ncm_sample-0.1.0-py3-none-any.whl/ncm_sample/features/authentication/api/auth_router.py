"""
Authentication API Router
"""

import logging
from datetime import datetime
from fastapi import APIRouter, HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
from ncm_foundation.core.logging.manager import correlation_id_var
from ncm_sample.config import settings
from ncm_sample.features.user_management.schemas import LoginRequest, LoginResponse, HealthResponse
from ncm_sample.features.authentication.services import AuthService
from ncm_sample.api import get_current_user  # Import from main API file
from ncm_sample.di.container import container, get_provider
from fastapi import Depends

# Import global services
logger = logging.getLogger(__name__)
AUTH_SVC_KEY = "auth_service"

# Module no longer uses a global auth_service; handlers will request it via DI

router = APIRouter(prefix="/auth", tags=["Authentication"])


def init_feature(auth_svc: AuthService = None):
    """Initialize module-level auth_service for the authentication feature.

    Returns the configured router. This allows the main application to
    call feature-level initialization during startup and keep `api.py`
    simpler.
    """
    real_auth = auth_svc or AuthService()
    container.register_singleton(AUTH_SVC_KEY, real_auth)
    return router


# Security (using the one from main API)
security = HTTPBearer()


@router.post("/login", response_model=LoginResponse)
async def login(login_data: LoginRequest, auth_service: AuthService = Depends(get_provider(AUTH_SVC_KEY))):
    """Login endpoint."""
    correlation_id = correlation_id_var.get()

    logger.info(f"Login attempt for user: {login_data.username}", extra={
                "correlation_id": correlation_id})

    if not auth_service:
        logger.error("Auth service not initialized", extra={
                     "correlation_id": correlation_id})
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Authentication service not available"
        )

    try:
        result = await auth_service.login(login_data.username, login_data.password)
        if not result:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Incorrect username or password"
            )

        logger.info(f"User {login_data.username} logged in successfully", extra={
                    "correlation_id": correlation_id})
        return LoginResponse(**result)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Login failed: {e}", extra={
                     "correlation_id": correlation_id})
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Login failed"
        )


@router.post("/logout")
async def logout():
    """Logout endpoint."""
    correlation_id = correlation_id_var.get()

    logger.info("User logging out", extra={"correlation_id": correlation_id})

    # In a real implementation, you would invalidate the token
    # For now, just log the logout
    return {"message": "Logged out successfully"}


@router.get("/me")
async def get_current_user_info():
    """Get current user information."""
    correlation_id = correlation_id_var.get()

    logger.info("Getting current user info", extra={
                "correlation_id": correlation_id})

    # In a real implementation, you would fetch user details from the database
    # For now, return basic info from token
    return {
        "message": "Current user information - authentication required"
    }


@router.get("/health", response_model=HealthResponse)
async def auth_health_check(auth_service: AuthService = Depends(get_provider(AUTH_SVC_KEY))):
    """Health check endpoint for authentication."""
    correlation_id = correlation_id_var.get()

    try:
        # Check if auth service is available
        auth_healthy = auth_service is not None

        services = {
            "auth_service": auth_healthy,
            "jwt_validation": True,  # JWT validation is always available
        }

        overall_status = "healthy" if all(services.values()) else "unhealthy"

        return HealthResponse(
            status=overall_status,
            timestamp=datetime.utcnow(),
            services=services,
            version=settings.app_version
        )

    except Exception as e:
        logger.error(f"Auth health check failed: {e}")
        return HealthResponse(
            status="unhealthy",
            timestamp=datetime.utcnow(),
            services={"error": str(e)},
            version=settings.app_version
        )
