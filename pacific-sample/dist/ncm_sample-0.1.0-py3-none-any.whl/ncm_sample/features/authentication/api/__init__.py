"""
Authentication API Router
"""

from .auth_router import router as auth_router, init_feature

__all__ = ["auth_router", "init_feature"]
