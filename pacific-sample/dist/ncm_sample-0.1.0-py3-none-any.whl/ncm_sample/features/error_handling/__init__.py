"""
Error Handling Integration using NCM Foundation
"""

from ncm_foundation.core.messaging.circuit_breaker import CircuitBreaker

__all__ = ["CircuitBreaker"]
