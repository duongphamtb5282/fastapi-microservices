"""
Utilities Integration using NCM Foundation
"""

from ncm_foundation.core.utils import (
    validate_email,
    validate_phone,
    validate_url,
    generate_uuid,
    format_datetime,
    sanitize_string,
    JSONEncoder,
    CustomJSONEncoder
)

__all__ = [
    "validate_email",
    "validate_phone",
    "validate_url",
    "generate_uuid",
    "format_datetime",
    "sanitize_string",
    "JSONEncoder",
    "CustomJSONEncoder"
]
