"""
FastAPI application for NCM Sample Project.
"""

# from ncm_sample.common.api import demo_router
# from ncm_sample.features.authentication.api import init_feature as auth_init_feature
# from ncm_sample.features.user_management.api import init_feature as user_init_feature
import asyncio
from datetime import datetime
from typing import List, Optional, Dict, Any
from fastapi import FastAPI, HTTPException, Depends, status, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from jose import JWTError, jwt
from ncm_foundation import (
    DatabaseManager, LogManager,
    get_logger, set_correlation_id,
)
from ncm_foundation.core.cache import CacheStrategy
from ncm_foundation.core.logging.manager import correlation_id_var, request_id_var, user_id_var
from ncm_foundation.core.logging.masking import SensitiveDataMasker
from ncm_foundation.core.security.middleware import CORSMiddleware, RateLimitMiddleware, SecurityMiddleware
# These are now imported from features
from ncm_sample.config import settings
from ncm_sample.features.user_management.schemas import (
    HealthResponse
)
from ncm_sample.features.user_management.services import UserService, RoleService, UserRoleService
from ncm_sample.features.authentication.services import AuthService
from ncm_sample.features.messaging.services import MessagingService, NotificationService
from ncm_sample.features.monitoring import HealthCheckManager
from ncm_sample.features.security import KeycloakManager, KeycloakConfig
# from ncm_sample.features.utilities import validate_email, validate_phone, generate_uuid

# Initialize logger and masker
logger = get_logger(__name__)
sensitive_masker = SensitiveDataMasker()

# Import feature routers and their init hooks

# Create routers for other features (these would be imported from their respective modules)
messaging_router = None  # Would be imported from messaging.api
monitoring_router = None  # Would be imported from monitoring.api
security_router = None    # Would be imported from security.api

# Logging middleware


# @app.middleware("http")
# async def logging_middleware(request: Request, call_next):
#     """Enhanced logging middleware with correlation IDs and request tracking."""
#     # Generate correlation and request IDs
#     correlation_id = request.headers.get("X-Correlation-ID", str(uuid.uuid4()))
#     request_id = str(uuid.uuid4())

#     # Set context variables
#     correlation_id_var.set(correlation_id)
#     request_id_var.set(request_id)
#     set_correlation_id(correlation_id)

#     # Extract user info if available
#     user_id = None
#     if hasattr(request.state, 'user'):
#         user_id = getattr(request.state.user, 'id', None)
#         if user_id:
#             user_id_var.set(str(user_id))

#     start_time = datetime.utcnow()

#     # Log request
#     logger.info(
#         f"Request started: {request.method} {request.url.path}",
#         extra={
#             "correlation_id": correlation_id,
#             "request_id": request_id,
#             "method": request.method,
#             "path": request.url.path,
#             "query_params": dict(request.query_params),
#             "user_agent": request.headers.get("user-agent"),
#             "ip": request.client.host if request.client else None,
#         }
#     )

#     try:
#         response = await call_next(request)

#         # Calculate duration
#         duration = (datetime.utcnow() - start_time).total_seconds()

#         # Log response
#         logger.info(
#             f"Request completed: {request.method} {request.url.path} - {response.status_code}",
#             extra={
#                 "correlation_id": correlation_id,
#                 "request_id": request_id,
#                 "method": request.method,
#                 "path": request.url.path,
#                 "status_code": response.status_code,
#                 "duration_seconds": duration,
#             }
#         )

#         # Add correlation ID to response headers
#         response.headers["X-Correlation-ID"] = correlation_id
#         response.headers["X-Request-ID"] = request_id

#         return response

#     except Exception as e:
#         # Calculate duration
#         duration = (datetime.utcnow() - start_time).total_seconds()

#         # Log error with sensitive data masking
#         error_data = {
#             "correlation_id": correlation_id,
#             "request_id": request_id,
#             "method": request.method,
#             "path": request.url.path,
#             "error": str(e),
#             "duration_seconds": duration,
#         }

#         # Mask sensitive data in error logs
#         masked_error_data = sensitive_masker.mask_sensitive_data(error_data)

#         logger.error(
#             f"Request failed: {request.method} {request.url.path}",
#             extra=masked_error_data
#         )

#         raise

# Initialize FastAPI app with enhanced configuration and versioning
app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description="NCM Sample Project demonstrating Foundation Library",
    docs_url="/docs" if settings.debug else None,
    redoc_url="/redoc" if settings.debug else None,
)

# API versioning setup
api_v1 = FastAPI(
    title=f"{settings.app_name} API v1",
    version="1.0.0",
    description="Version 1 of NCM Sample API",
    docs_url="/docs/v1" if settings.debug else None,
    redoc_url="/redoc/v1" if settings.debug else None,
)

# Mount API versions
app.mount("/api/v1", api_v1)

# Add CORS middleware from ncm-foundation
if settings.cors_origins:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

# Add rate limiting middleware from ncm-foundation
app.add_middleware(
    RateLimitMiddleware,
    requests_per_minute=settings.get('api_rate_limit_per_minute', 100),
    burst_limit=settings.get('api_rate_limit_burst', 10),
)

# Add security middleware from ncm-foundation
app.add_middleware(
    SecurityMiddleware,
    enable_security_headers=True,
    enable_request_validation=True,
)

# Add trusted host middleware for security (fallback)
if not settings.debug:
    app.add_middleware(
        TrustedHostMiddleware,
        allowed_hosts=settings.get("trusted_hosts", ["*"])
    )

# Security
security = HTTPBearer()

# Global managers
db_manager: Optional[DatabaseManager] = None
# cache_manager: Optional[CacheManager] = None
log_manager: Optional[LogManager] = None
health_manager: Optional[HealthCheckManager] = None
# migration_manager: Optional[MigrationManager] = None
keycloak_manager: Optional[KeycloakManager] = None

# Services
user_service: Optional[UserService] = None
role_service: Optional[RoleService] = None
user_role_service: Optional[UserRoleService] = None
auth_service: Optional[AuthService] = None
messaging_service: Optional[MessagingService] = None
notification_service: Optional[NotificationService] = None


@app.on_event("startup")
async def startup_event():
    """Initialize services on startup."""
    global db_manager, cache_manager, log_manager
    global user_service, role_service, user_role_service, auth_service

    logger.info("Starting NCM Sample application...")

    try:
        # Create configs for testing
        from ncm_foundation.core.database import DatabaseConfig, DatabaseType
        from ncm_foundation.core.cache import CacheConfig
        from ncm_foundation.core.logging import LogConfig, LogLevel

        db_config = DatabaseConfig(
            db_type=DatabaseType.POSTGRESQL,
            host="localhost",
            port=5432,
            database="test",
            username="auth_user",
            password="auth_password"
        )

        cache_config = CacheConfig(
            default_ttl=3600,
            max_connections=10
        )

        log_config = LogConfig(
            level=LogLevel.INFO,
            format="json"
        )

        # Initialize managers
        db_manager = DatabaseManager(db_config)
        cache_manager = CacheManager(cache_config)
        log_manager = LogManager(log_config)
        # health_manager = HealthCheckManager(db_manager, cache_manager)
        # migration_manager = migration_manager(settings.database_url)

        # Initialize Keycloak manager if configured
        keycloak_manager = None
        if settings.get('keycloak_server_url'):
            keycloak_config = KeycloakConfig(
                server_url=settings.keycloak_server_url,
                realm=settings.get('keycloak_realm', 'master'),
                client_id=settings.keycloak_client_id,
                client_secret=settings.keycloak_client_secret,
                admin_username=settings.keycloak_admin_username,
                admin_password=settings.keycloak_admin_password,
            )
            keycloak_manager = KeycloakManager(keycloak_config)
            await keycloak_manager.start()

        # Start all services concurrently for better performance
        await asyncio.gather(
            db_manager.start(),
            # cache_manager.start(),
            log_manager.start(),
            keycloak_manager.start() if keycloak_manager else asyncio.sleep(0),
        )

        # Set cache strategy
        # cache_manager.set_strategy(CacheStrategy.WRITE_THROUGH)

        # Initialize services at feature level by calling their init hooks.
        # This keeps feature routers self-contained and moves initialization
        # into the feature packages.
        # user_router = user_init_feature(db_manager, cache_manager)
        # auth_router = auth_init_feature()  # authentication may create its own service

        # # Initialize messaging services if enabled
        # if settings.enable_circuit_breaker:
        #     messaging_service = MessagingService()
        #     await messaging_service.start()
        #     notification_service = NotificationService(messaging_service)

        #     # Register message handlers
        #     messaging_service.register_message_handler(
        #         "user_created", handle_user_created_event)
        #     messaging_service.register_message_handler(
        #         "user_updated", handle_user_updated_event)

        #     # Start consuming messages if Kafka is available
        #     try:
        #         await messaging_service.start_consuming([
        #             f"{settings.kafka_topic_prefix}.user.*",
        #             f"{settings.kafka_topic_prefix}.system.*"
        #         ])
        #     except Exception as e:
        #         logger.warning(f"Failed to start message consumption: {e}")

        # Include feature routers in API v1
        # api_v1.include_router(user_router)
        # api_v1.include_router(auth_router)
        # api_v1.include_router(demo_router)

        # Include other routers when they are implemented
        # api_v1.include_router(messaging_router)
        # api_v1.include_router(monitoring_router)
        # api_v1.include_router(security_router)

        logger.info("All services started successfully")

    except Exception as e:
        logger.error(f"Failed to start services: {e}")
        raise


@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup services on shutdown."""
    # global db_manager, cache_manager, log_manager, messaging_service, keycloak_manager

    # logger.info("Shutting down NCM Sample application...")

    # try:
    #     # Stop messaging service
    #     if messaging_service:
    #         await messaging_service.stop()

    #     # Stop Keycloak manager
    #     if keycloak_manager:
    #         await keycloak_manager.stop()

    #     if cache_manager:
    #         await cache_manager.stop()
    #     if db_manager:
    #         await db_manager.stop()
    #     if log_manager:
    #         await log_manager.stop()

    logger.info("All services stopped successfully")

    except Exception as e:
        logger.error(f"Error during shutdown: {e}")


# # Message handlers for Kafka events
# async def handle_user_created_event(message: Dict[str, Any]):
#     """Handle user created events."""
#     logger.info("Processing user created event", extra={
#         "user_id": message.get("user_id"),
#         "event_type": message.get("event_type"),
#         "service": message.get("service")
#     })

#     # Here you could trigger additional business logic
#     # For example: send welcome email, update analytics, etc.


# async def handle_user_updated_event(message: Dict[str, Any]):
#     """Handle user updated events."""
#     logger.info("Processing user updated event", extra={
#         "user_id": message.get("user_id"),
#         "event_type": message.get("event_type"),
#         "service": message.get("service"),
#         "changes": message.get("data", {}).get("changes")
#     })

#     # Here you could trigger additional business logic
#     # For example: update user preferences, sync with external systems, etc.


# def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)) -> dict:
#     """Get current user from JWT token."""
#     credentials_exception = HTTPException(
#         status_code=status.HTTP_401_UNAUTHORIZED,
#         detail="Could not validate credentials",
#         headers={"WWW-Authenticate": "Bearer"},
#     )

#     try:
#         payload = jwt.decode(credentials.credentials, settings.jwt_secret, algorithms=[
#                              settings.jwt_algorithm])
#         username: str = payload.get("sub")
#         user_id: int = payload.get("user_id")

#         if username is None or user_id is None:
#             raise credentials_exception

#         return {"username": username, "user_id": user_id}

#     except JWTError:
#         raise credentials_exception


# # Health check endpoint (moved to common feature)
# @app.get("/health")
# async def health_check():
#     """General health check endpoint."""
#     correlation_id = correlation_id_var.get()

#     # Use the health manager from features
#     if health_manager:
#         overall_health = await health_manager.get_overall_health()
#         return HealthResponse(
#             status=overall_health.get("status"),
#             timestamp=datetime.utcnow(),
#             services=overall_health.get("services", {}),
#             version=settings.app_version
#         )

#     # Fallback health check
#     services = {"api": "healthy"}
#     return HealthResponse(
#         status="healthy",
#         timestamp=datetime.utcnow(),
#         services=services,
#         version=settings.app_version
#     )


# Authentication endpoints moved to authentication feature


# User endpoints moved to user_management feature
# Role endpoints moved to user_management feature
# User role endpoints moved to user_management feature


# Cache testing endpoints moved to user_management feature


# Demo endpoints moved to common feature


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
