"""DI container adapter for the app.

Prefer `pynest-api` if it's available; otherwise provide a tiny fallback
container with a register/resolve API. The rest of the app should depend on
`container.register` and `container.resolve` and use `get_provider` to create
FastAPI dependency callables.
"""
from typing import Any, Callable

try:
    # If pynest-api is installed and exposes a Container class, prefer it.
    from pynest_api import Container as PynestContainer  # type: ignore

    class AppContainer(PynestContainer):
        pass

    container = AppContainer()

except Exception:
    class AppContainer:
        def __init__(self) -> None:
            self._providers: dict[Any, Callable[[], Any]] = {}

        def register(self, key: Any, provider: Callable[[], Any]) -> None:
            """Register a provider for `key`. Provider is a zero-arg callable that returns an instance."""
            self._providers[key] = provider

        def register_singleton(self, key: Any, instance: Any) -> None:
            self._providers[key] = lambda: instance

        def resolve(self, key: Any) -> Any:
            provider = self._providers.get(key)
            if provider is None:
                raise RuntimeError(f"No provider registered for {key}")
            return provider()

    container = AppContainer()


def get_provider(key: Any):
    """Return a FastAPI-compatible dependency callable that resolves `key` from the container."""
    def _dep():
        return container.resolve(key)

    return _dep
