"""Compatibility decorators for py-nest-style annotations.

If `pynest_api` is available, re-export its decorators. Otherwise provide
no-op decorators so code can be annotated uniformly.
"""
from typing import Any, Callable

try:
    from pynest_api import Controller, Service, Repository  # type: ignore
except Exception:
    # Fallback no-op decorators
    def Controller(cls: Any) -> Any:
        return cls

    def Service(cls: Any) -> Any:
        return cls

    def Repository(cls: Any) -> Any:
        return cls

__all__ = ["Controller", "Service", "Repository"]
