"""
NCM Sample Project demonstrating Foundation Library usage.
"""

__version__ = "0.1.0"
__author__ = "NCM Team"
