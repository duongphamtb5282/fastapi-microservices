"""
Role Repository - Data Access Layer
"""

from typing import Any, Dict, List, Optional
from sqlalchemy import select, and_, or_, desc, asc
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from ncm_foundation.core.database.repositories.sqlalchemy_repo import SQLAlchemyRepository
from ncm_foundation.core.logging import get_logger
from ncm_sample.features.user_management.models import Role, UserRole

logger = get_logger(__name__)


class RoleRepository(SQLAlchemyRepository[Role]):
    """Repository for Role entities using NCM Foundation SQLAlchemyRepository."""

    def __init__(self, session: AsyncSession):
        super().__init__(Role, session)

    async def get_by_name(self, name: str) -> Optional[Role]:
        """Get role by name with users loaded."""
        result = await self.session.execute(
            select(Role)
            .where(Role.name == name)
            .options(selectinload(Role.users))
        )
        return result.scalar_one_or_none()

    async def activate_role(self, role_id: Any) -> bool:
        """Activate role."""
        return await self.update(role_id, {"is_active": True}) is not None

    async def deactivate_role(self, role_id: Any) -> bool:
        """Deactivate role."""
        return await self.update(role_id, {"is_active": False}) is not None

    async def search_roles(self, search_term: str, limit: int = 20) -> List[Role]:
        """Search roles by name or description."""
        return await self.search(
            query=search_term,
            fields=["name", "description"],
            limit=limit
        )

    async def get_roles_by_user(self, user_id: str) -> List[Role]:
        """Get roles by user ID."""
        # This is a complex query that requires custom implementation
        result = await self.session.execute(
            select(Role)
            .join(UserRole)
            .where(UserRole.user_id == user_id)
            .where(UserRole.is_active == True)
            .options(selectinload(Role.users))
        )
        return result.scalars().all()

    async def get_active_roles(self, limit: int = 100, offset: int = 0) -> List[Role]:
        """Get active roles."""
        return await self.list(
            filters={"is_active": True},
            limit=limit,
            offset=offset,
            order_by="name"
        )
