"""
Authentication Services for NCM Sample Project.
"""

import asyncio
from datetime import datetime, timedelta
from typing import Optional
from passlib.context import CryptContext
from jose import JWTError, jwt
from ncm_foundation import get_logger, CacheManager, DatabaseManager
from ncm_sample.config import settings

logger = get_logger(__name__)

# Password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


class AuthService:
    """Authentication service with JWT and password management."""

    def __init__(self, db_manager: DatabaseManager, cache_manager: CacheManager):
        self.db_manager = db_manager
        self.cache_manager = cache_manager

    def verify_password(self, plain_password: str, hashed_password: str) -> bool:
        """Verify password."""
        return pwd_context.verify(plain_password, hashed_password)

    def create_access_token(self, data: dict, expires_delta: Optional[timedelta] = None) -> str:
        """Create access token."""
        to_encode = data.copy()
        if expires_delta:
            expire = datetime.utcnow() + expires_delta
        else:
            expire = datetime.utcnow() + timedelta(minutes=settings.jwt_expire_minutes)

        to_encode.update({"exp": expire})
        encoded_jwt = jwt.encode(to_encode, settings.jwt_secret, algorithm=settings.jwt_algorithm)
        return encoded_jwt

    async def authenticate_user(self, username: str, password: str) -> Optional[User]:
        """Authenticate user using user management service."""
        # Import here to avoid circular imports
        from ncm_sample.features.user_management.services import UserService

        user_service = UserService(self.db_manager, self.cache_manager)
        user = await user_service.get_user_by_email(username)

        if not user:
            return None

        if not self.verify_password(password, user.password_hash):
            return None

        return user

    async def login(self, username: str, password: str) -> Optional[dict]:
        """Login user and return token."""
        user = await self.authenticate_user(username, password)
        if not user:
            return None

        access_token_expires = timedelta(minutes=settings.jwt_expire_minutes)
        access_token = self.create_access_token(
            data={"sub": user.username, "user_id": user.id},
            expires_delta=access_token_expires
        )

        return {
            "access_token": access_token,
            "token_type": "bearer",
            "expires_in": settings.jwt_expire_minutes * 60,
            "user": user
        }
